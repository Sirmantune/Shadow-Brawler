# Shadow Brawler — Android Project

A native Android side-view brawler (Kotlin), inspired by "Shadow of Death."
3 playable characters, each with a 6-node skill tree, wave-based combat,
and a soul-point currency earned from fights.

## What's included
- Full Android Studio project (Gradle/Kotlin, no Flutter/web — 100% native)
- Main Menu → Character Select → Skill Tree → Game screens
- Custom 2D game loop built on `SurfaceView` (no external game engine needed)
- 3 characters: Blade Knight, Shadow Assassin, Iron Juggernaut
- Skill tree per character (damage, HP, speed, attack speed, special damage, lifesteal)
- Touch controls: move left/right, basic attack, special attack
- Progress (soul points + unlocked skills) saved locally via SharedPreferences

## How to build the APK

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this project anywhere on your computer.
3. Open Android Studio → **Open** → select the unzipped `ShadowBrawler` folder.
4. Wait for Gradle sync to finish (first time it downloads the Android SDK
   components and dependencies — needs internet, only on your machine).
5. Plug in an Android phone (USB debugging on) or use an emulator.
6. Click the green ▶ **Run** button, or go to
   **Build → Build Bundle(s) / APK(s) → Build APK(s)** to generate an
   installable `.apk` file (found in `app/build/outputs/apk/debug/`).

## Project structure
```
app/src/main/java/com/shadowbrawler/game/
  Characters.kt        - 3 character definitions (stats, special attacks)
  SkillTrees.kt         - skill tree data + SharedPreferences progress store
  Fighter.kt            - runtime combat entity + stat math from skills
  GameView.kt            - the actual game loop, rendering, controls, AI
  MainMenuActivity.kt
  CharacterSelectActivity.kt
  SkillTreeActivity.kt
  GameActivity.kt
app/src/main/res/        - layouts, colors, strings, theme
```

## Easiest next upgrades
- Swap the rectangle placeholder art for real stickman sprites/animations
  (drop PNGs into `res/drawable` and reference them in `GameView.kt`'s
  `drawFighter` function).
- Add sound effects with `SoundPool` in `GameView`.
- Add more waves/bosses by extending the `Fighter.buildEnemy` scaling curve.
- Add more characters by adding entries to `Characters.kt` and `SkillTrees.kt`.

## Why no APK file is included
Compiling a real `.apk` requires the Android SDK + Gradle, which need
internet access to download — something not available in the sandbox that
generated this project. Opening the project in Android Studio resolves
this automatically on your machine.
