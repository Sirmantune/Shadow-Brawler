package com.shadowbrawler.game

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainMenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        findViewById<android.widget.Button>(R.id.btnPlay).setOnClickListener {
            startActivity(Intent(this, CharacterSelectActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.btnExit).setOnClickListener {
            finish()
        }
    }
}
