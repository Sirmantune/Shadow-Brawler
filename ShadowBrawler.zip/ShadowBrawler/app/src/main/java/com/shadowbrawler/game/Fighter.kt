package com.shadowbrawler.game

import kotlin.math.max

/**
 * A runtime fighter instance — either the player (built from a CharacterDef
 * plus unlocked skill bonuses) or an enemy (built with flat scaling).
 */
class Fighter(
    val name: String,
    var maxHp: Int,
    var damage: Int,
    var speed: Float,
    var attackCooldownMs: Long,
    var specialDamage: Int,
    var specialCooldownMs: Long,
    var lifestealPercent: Float,
    val color: Int,
    var x: Float,
    var groundY: Float,
    val isEnemy: Boolean
) {
    var hp: Int = maxHp
    var facingRight: Boolean = !isEnemy
    var lastAttackTime: Long = 0L
    var lastSpecialTime: Long = 0L
    var isAttacking: Boolean = false
    var attackAnimEndTime: Long = 0L
    var isDead: Boolean = false
    var velocityX: Float = 0f

    val isAlive: Boolean get() = hp > 0 && !isDead

    fun canBasicAttack(now: Long): Boolean = now - lastAttackTime >= attackCooldownMs
    fun canSpecial(now: Long): Boolean = now - lastSpecialTime >= specialCooldownMs

    fun takeDamage(amount: Int) {
        hp = max(0, hp - amount)
        if (hp == 0) isDead = true
    }

    fun heal(amount: Int) {
        hp = (hp + amount).coerceAtMost(maxHp)
    }

    fun startBasicAttack(now: Long) {
        lastAttackTime = now
        isAttacking = true
        attackAnimEndTime = now + 150
    }

    fun startSpecial(now: Long) {
        lastSpecialTime = now
        isAttacking = true
        attackAnimEndTime = now + 350
    }

    companion object {
        /**
         * Builds the player's Fighter by applying all unlocked skill node
         * bonuses on top of the character's base stats.
         */
        fun buildPlayer(
            def: CharacterDef,
            unlocked: List<SkillNode>,
            equipped: List<EquipmentItem>,
            startX: Float,
            groundY: Float
        ): Fighter {
            var dmgMult = 1f
            var hpMult = 1f
            var speedMult = 1f
            var atkSpeedMult = 1f
            var specialMult = 1f
            var lifesteal = 0f

            // Build one combined list of (effect, magnitude) pairs from both
            // skills and equipment so there is exactly one place stat bonuses
            // get summed — skills and gear can never be computed differently.
            val allBonuses = mutableListOf<Pair<SkillEffect, Float>>()
            for (skill in unlocked) allBonuses.add(skill.effect to skill.magnitude)
            for (item in equipped) {
                for ((effect, magnitude) in item.bonuses) allBonuses.add(effect to magnitude)
            }

            for ((effect, magnitude) in allBonuses) {
                when (effect) {
                    SkillEffect.DAMAGE_PERCENT -> dmgMult += magnitude
                    SkillEffect.HP_PERCENT -> hpMult += magnitude
                    SkillEffect.SPEED_PERCENT -> speedMult += magnitude
                    SkillEffect.ATTACK_SPEED_PERCENT -> atkSpeedMult -= magnitude
                    SkillEffect.SPECIAL_DAMAGE_PERCENT -> specialMult += magnitude
                    SkillEffect.LIFESTEAL_PERCENT -> lifesteal += magnitude
                }
            }

            val finalCooldown = (def.attackSpeedMs * atkSpeedMult.coerceAtLeast(0.3f)).toLong()

            return Fighter(
                name = def.displayName,
                maxHp = (def.baseHp * hpMult).toInt(),
                damage = (def.baseDamage * dmgMult).toInt(),
                speed = def.baseSpeed * speedMult,
                attackCooldownMs = finalCooldown,
                specialDamage = (def.specialDamage * specialMult).toInt(),
                specialCooldownMs = def.specialCooldownMs,
                lifestealPercent = lifesteal,
                color = def.color,
                x = startX,
                groundY = groundY,
                isEnemy = false
            )
        }

        /**
         * Builds an enemy Fighter, scaled up gradually per wave number so
         * later waves are tougher.
         */
        fun buildEnemy(waveNumber: Int, startX: Float, groundY: Float): Fighter {
            val scale = 1f + (waveNumber - 1) * 0.18f
            return Fighter(
                name = "Shadow Wraith",
                maxHp = (40 * scale).toInt(),
                damage = (5 * scale).toInt(),
                speed = (3.5f + waveNumber * 0.15f).coerceAtMost(7f),
                attackCooldownMs = 700,
                specialDamage = 0,
                specialCooldownMs = Long.MAX_VALUE,
                lifestealPercent = 0f,
                color = android.graphics.Color.parseColor("#2B2B3A"),
                x = startX,
                groundY = groundY,
                isEnemy = true
            )
        }
    }
}
