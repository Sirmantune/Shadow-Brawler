package com.shadowbrawler.game

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CharacterSelectActivity : AppCompatActivity() {

    private var selectedCharacterId: String = Characters.ALL.first().id
    private val cardViews = mutableMapOf<String, LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_character_select)

        val container = findViewById<LinearLayout>(R.id.characterContainer)
        val inflater = LayoutInflater.from(this)

        for (def in Characters.ALL) {
            val card = inflater.inflate(R.layout.item_character_card, container, false) as LinearLayout
            card.findViewById<android.view.View>(R.id.colorSwatch).setBackgroundColor(def.color)
            card.findViewById<TextView>(R.id.charName).text = def.displayName
            card.findViewById<TextView>(R.id.charDesc).text = def.description
            card.setOnClickListener { selectCharacter(def.id) }
            container.addView(card)
            cardViews[def.id] = card
        }
        highlightSelected()

        findViewById<Button>(R.id.btnSkillTree).setOnClickListener {
            val intent = Intent(this, SkillTreeActivity::class.java)
            intent.putExtra("characterId", selectedCharacterId)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnEquipment).setOnClickListener {
            val intent = Intent(this, EquipmentActivity::class.java)
            intent.putExtra("characterId", selectedCharacterId)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnFight).setOnClickListener {
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra("characterId", selectedCharacterId)
            startActivity(intent)
        }
    }

    private fun selectCharacter(id: String) {
        selectedCharacterId = id
        highlightSelected()
        Toast.makeText(this, Characters.byId(id).displayName + " selected", Toast.LENGTH_SHORT).show()
    }

    private fun highlightSelected() {
        for ((id, view) in cardViews) {
            view.setBackgroundColor(
                if (id == selectedCharacterId) resources.getColor(R.color.accent_purple, theme)
                else resources.getColor(R.color.panel_dark, theme)
            )
        }
    }
}
