package com.shadowbrawler.game

import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class GameActivity : AppCompatActivity(), GameListener {

    private lateinit var characterId: String
    private lateinit var store: ProgressStore
    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        characterId = intent.getStringExtra("characterId") ?: Characters.ALL.first().id
        store = ProgressStore(this)

        val def = Characters.byId(characterId)
        val unlocked = store.unlockedSkillsFor(characterId)
        val equipped = store.equippedItemsFor(characterId)

        gameView = GameView(this, def, unlocked, equipped, this)
        findViewById<FrameLayout>(R.id.gameRoot).addView(gameView)
    }

    override fun onGameOver(victory: Boolean, soulsEarned: Int, waveReached: Int, droppedItemIds: List<String>) {
        store.addSoulPoints(soulsEarned)

        val newItems = mutableListOf<String>()
        for (itemId in droppedItemIds) {
            if (!store.isItemOwned(itemId)) {
                store.ownItem(itemId)
                EquipmentCatalog.byId(itemId)?.let { newItems.add("${it.rarity.displayName}: ${it.name}") }
            }
        }

        val title = if (victory) "VICTORY!" else "DEFEATED"
        val dropText = if (newItems.isNotEmpty()) "\n\nItems found:\n" + newItems.joinToString("\n") else ""
        val message = "Reached wave $waveReached\nSouls earned: $soulsEarned\nTotal souls: ${store.getSoulPoints()}$dropText"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton("CONTINUE") { _, _ -> finish() }
            .show()
    }
}
