package com.shadowbrawler.game

import android.content.Context
import android.content.SharedPreferences

enum class SkillEffect {
    DAMAGE_PERCENT,   // +% to basic attack damage
    HP_PERCENT,       // +% to max HP
    SPEED_PERCENT,    // +% to move speed
    ATTACK_SPEED_PERCENT, // -% cooldown on basic attack (faster combos)
    SPECIAL_DAMAGE_PERCENT, // +% special attack damage
    LIFESTEAL_PERCENT // % of damage dealt returned as HP
}

data class SkillNode(
    val id: String,
    val tier: Int,                 // 1, 2, or 3 - tier 2 requires a tier 1 unlocked, etc.
    val name: String,
    val description: String,
    val cost: Int,                 // soul points required to unlock
    val effect: SkillEffect,
    val magnitude: Float,          // e.g. 0.15f = 15%
    val requires: String? = null   // id of prerequisite node, null if tier 1
)

object SkillTrees {
    // Each character gets the same 6-node shape (2 per tier) but
    // flavored toward their archetype.
    fun treeFor(characterId: String): List<SkillNode> = when (characterId) {
        "blade_knight" -> listOf(
            SkillNode("bk_t1_power", 1, "Honed Edge", "+15% basic attack damage", 1, SkillEffect.DAMAGE_PERCENT, 0.15f),
            SkillNode("bk_t1_vitality", 1, "Knight's Resolve", "+15% max HP", 1, SkillEffect.HP_PERCENT, 0.15f),
            SkillNode("bk_t2_speed", 2, "Swift Footwork", "+20% move speed", 2, SkillEffect.SPEED_PERCENT, 0.20f, "bk_t1_power"),
            SkillNode("bk_t2_combo", 2, "Combo Mastery", "-20% attack cooldown", 2, SkillEffect.ATTACK_SPEED_PERCENT, 0.20f, "bk_t1_vitality"),
            SkillNode("bk_t3_dragon", 3, "Dragon's Fury", "+40% special damage", 3, SkillEffect.SPECIAL_DAMAGE_PERCENT, 0.40f, "bk_t2_speed"),
            SkillNode("bk_t3_drain", 3, "Soul Drain", "10% lifesteal on hit", 3, SkillEffect.LIFESTEAL_PERCENT, 0.10f, "bk_t2_combo")
        )
        "shadow_assassin" -> listOf(
            SkillNode("sa_t1_power", 1, "Sharpened Fangs", "+15% basic attack damage", 1, SkillEffect.DAMAGE_PERCENT, 0.15f),
            SkillNode("sa_t1_speed", 1, "Shadow Step", "+20% move speed", 1, SkillEffect.SPEED_PERCENT, 0.20f),
            SkillNode("sa_t2_combo", 2, "Flurry", "-25% attack cooldown", 2, SkillEffect.ATTACK_SPEED_PERCENT, 0.25f, "sa_t1_power"),
            SkillNode("sa_t2_vitality", 2, "Wraith Form", "+15% max HP", 2, SkillEffect.HP_PERCENT, 0.15f, "sa_t1_speed"),
            SkillNode("sa_t3_void", 3, "Void Mastery", "+45% special damage", 3, SkillEffect.SPECIAL_DAMAGE_PERCENT, 0.45f, "sa_t2_combo"),
            SkillNode("sa_t3_drain", 3, "Blood Thirst", "15% lifesteal on hit", 3, SkillEffect.LIFESTEAL_PERCENT, 0.15f, "sa_t2_vitality")
        )
        "iron_juggernaut" -> listOf(
            SkillNode("ij_t1_vitality", 1, "Iron Hide", "+20% max HP", 1, SkillEffect.HP_PERCENT, 0.20f),
            SkillNode("ij_t1_power", 1, "Crushing Blows", "+15% basic attack damage", 1, SkillEffect.DAMAGE_PERCENT, 0.15f),
            SkillNode("ij_t2_speed", 2, "Momentum", "+15% move speed", 2, SkillEffect.SPEED_PERCENT, 0.15f, "ij_t1_vitality"),
            SkillNode("ij_t2_combo", 2, "Relentless", "-15% attack cooldown", 2, SkillEffect.ATTACK_SPEED_PERCENT, 0.15f, "ij_t1_power"),
            SkillNode("ij_t3_slam", 3, "Cataclysm", "+50% special damage", 3, SkillEffect.SPECIAL_DAMAGE_PERCENT, 0.50f, "ij_t2_speed"),
            SkillNode("ij_t3_drain", 3, "Grim Vigor", "12% lifesteal on hit", 3, SkillEffect.LIFESTEAL_PERCENT, 0.12f, "ij_t2_combo")
        )
        else -> emptyList()
    }
}

/**
 * Handles saved progress: soul points (earned currency) and which
 * skill node ids are unlocked per character. Backed by SharedPreferences
 * so progress survives app restarts.
 */
class ProgressStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("shadow_brawler_progress", Context.MODE_PRIVATE)

    fun getSoulPoints(): Int = prefs.getInt("soul_points", 0)

    fun addSoulPoints(amount: Int) {
        prefs.edit().putInt("soul_points", getSoulPoints() + amount).apply()
    }

    fun spendSoulPoints(amount: Int): Boolean {
        val current = getSoulPoints()
        if (current < amount) return false
        prefs.edit().putInt("soul_points", current - amount).apply()
        return true
    }

    fun isUnlocked(characterId: String, skillId: String): Boolean =
        prefs.getBoolean("unlock_${characterId}_$skillId", false)

    fun unlock(characterId: String, skillId: String) {
        prefs.edit().putBoolean("unlock_${characterId}_$skillId", true).apply()
    }

    fun unlockedSkillsFor(characterId: String): List<SkillNode> =
        SkillTrees.treeFor(characterId).filter { isUnlocked(characterId, it.id) }

    // ---- Equipment ----
    fun isItemOwned(itemId: String): Boolean =
        prefs.getBoolean("item_owned_$itemId", false)

    fun ownItem(itemId: String) {
        prefs.edit().putBoolean("item_owned_$itemId", true).apply()
    }

    fun getEquippedWeapon(characterId: String): String? =
        prefs.getString("equipped_weapon_$characterId", null)

    fun getEquippedArmor(characterId: String): String? =
        prefs.getString("equipped_armor_$characterId", null)

    fun setEquippedWeapon(characterId: String, itemId: String?) {
        prefs.edit().putString("equipped_weapon_$characterId", itemId).apply()
    }

    fun setEquippedArmor(characterId: String, itemId: String?) {
        prefs.edit().putString("equipped_armor_$characterId", itemId).apply()
    }

    fun equippedItemsFor(characterId: String): List<EquipmentItem> {
        val result = mutableListOf<EquipmentItem>()
        getEquippedWeapon(characterId)?.let { id -> EquipmentCatalog.byId(id)?.let { result.add(it) } }
        getEquippedArmor(characterId)?.let { id -> EquipmentCatalog.byId(id)?.let { result.add(it) } }
        return result
    }
}
