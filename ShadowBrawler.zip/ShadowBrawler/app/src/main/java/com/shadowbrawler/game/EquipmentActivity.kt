package com.shadowbrawler.game

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EquipmentActivity : AppCompatActivity() {

    private lateinit var characterId: String
    private lateinit var store: ProgressStore
    private lateinit var container: LinearLayout
    private lateinit var titleLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equipment)

        characterId = intent.getStringExtra("characterId") ?: Characters.ALL.first().id
        store = ProgressStore(this)
        container = findViewById(R.id.equipmentContainer)
        titleLabel = findViewById(R.id.equipmentTitle)

        findViewById<Button>(R.id.btnBackEquip).setOnClickListener { finish() }

        render()
    }

    private fun render() {
        container.removeAllViews()
        titleLabel.text = "EQUIPMENT - ${Characters.byId(characterId).displayName}"

        val inflater = LayoutInflater.from(this)
        addSectionHeader("WEAPON")
        for (item in EquipmentCatalog.weapons()) addItemRow(inflater, item, EquipmentSlot.WEAPON)

        addSectionHeader("ARMOR")
        for (item in EquipmentCatalog.armors()) addItemRow(inflater, item, EquipmentSlot.ARMOR)
    }

    private fun addSectionHeader(label: String) {
        val header = TextView(this)
        header.text = label
        header.setTextColor(resources.getColor(R.color.accent_purple, theme))
        header.textSize = 16f
        header.setPadding(0, 24, 0, 8)
        container.addView(header)
    }

    private fun addItemRow(inflater: LayoutInflater, item: EquipmentItem, slot: EquipmentSlot) {
        val row = inflater.inflate(R.layout.item_skill_row, container, false)
        row.findViewById<TextView>(R.id.skillName).text = "${item.rarity.displayName} . ${item.name}"
        row.findViewById<TextView>(R.id.skillDesc).text = item.description
        val btn = row.findViewById<Button>(R.id.btnUnlock)

        val owned = store.isItemOwned(item.id)
        val equippedId = if (slot == EquipmentSlot.WEAPON) store.getEquippedWeapon(characterId) else store.getEquippedArmor(characterId)
        val isEquipped = equippedId == item.id

        when {
            !owned -> {
                btn.text = "LOCKED"
                btn.isEnabled = false
            }
            isEquipped -> {
                btn.text = "UNEQUIP"
                btn.isEnabled = true
                btn.setOnClickListener {
                    if (slot == EquipmentSlot.WEAPON) store.setEquippedWeapon(characterId, null)
                    else store.setEquippedArmor(characterId, null)
                    render()
                }
            }
            else -> {
                btn.text = "EQUIP"
                btn.isEnabled = true
                btn.setOnClickListener {
                    if (slot == EquipmentSlot.WEAPON) store.setEquippedWeapon(characterId, item.id)
                    else store.setEquippedArmor(characterId, item.id)
                    render()
                }
            }
        }
        container.addView(row)
    }
}
