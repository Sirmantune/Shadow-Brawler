package com.shadowbrawler.game

import kotlin.random.Random

enum class EquipmentSlot { WEAPON, ARMOR }

enum class Rarity(val displayName: String, val dropWeight: Int) {
    COMMON("Common", 60),
    RARE("Rare", 30),
    EPIC("Epic", 10)
}

/**
 * An equippable item. Bonuses reuse the same SkillEffect percentages as the
 * skill tree, so equipment and skills stack additively into the exact same
 * multipliers inside Fighter.buildPlayer — one unified stat pipeline, no
 * separate/duplicate math path that could drift out of sync.
 */
data class EquipmentItem(
    val id: String,
    val name: String,
    val slot: EquipmentSlot,
    val rarity: Rarity,
    val description: String,
    val bonuses: Map<SkillEffect, Float> // e.g. DAMAGE_PERCENT -> 0.10f
)

object EquipmentCatalog {
    val ALL = listOf(
        // ---- Weapons ----
        EquipmentItem(
            id = "wpn_rusty_blade",
            name = "Rusty Blade",
            slot = EquipmentSlot.WEAPON,
            rarity = Rarity.COMMON,
            description = "+8% basic attack damage",
            bonuses = mapOf(SkillEffect.DAMAGE_PERCENT to 0.08f)
        ),
        EquipmentItem(
            id = "wpn_twin_fangs",
            name = "Twin Fangs",
            slot = EquipmentSlot.WEAPON,
            rarity = Rarity.RARE,
            description = "+12% attack damage, -10% attack cooldown",
            bonuses = mapOf(
                SkillEffect.DAMAGE_PERCENT to 0.12f,
                SkillEffect.ATTACK_SPEED_PERCENT to 0.10f
            )
        ),
        EquipmentItem(
            id = "wpn_dragonfang_edge",
            name = "Dragonfang Edge",
            slot = EquipmentSlot.WEAPON,
            rarity = Rarity.EPIC,
            description = "+15% attack damage, +25% special damage",
            bonuses = mapOf(
                SkillEffect.DAMAGE_PERCENT to 0.15f,
                SkillEffect.SPECIAL_DAMAGE_PERCENT to 0.25f
            )
        ),
        EquipmentItem(
            id = "wpn_void_dagger",
            name = "Void Dagger",
            slot = EquipmentSlot.WEAPON,
            rarity = Rarity.RARE,
            description = "+10% attack damage, +8% lifesteal",
            bonuses = mapOf(
                SkillEffect.DAMAGE_PERCENT to 0.10f,
                SkillEffect.LIFESTEAL_PERCENT to 0.08f
            )
        ),

        // ---- Armor ----
        EquipmentItem(
            id = "arm_leather_vest",
            name = "Leather Vest",
            slot = EquipmentSlot.ARMOR,
            rarity = Rarity.COMMON,
            description = "+10% max HP",
            bonuses = mapOf(SkillEffect.HP_PERCENT to 0.10f)
        ),
        EquipmentItem(
            id = "arm_shadow_cloak",
            name = "Shadow Cloak",
            slot = EquipmentSlot.ARMOR,
            rarity = Rarity.RARE,
            description = "+12% max HP, +10% move speed",
            bonuses = mapOf(
                SkillEffect.HP_PERCENT to 0.12f,
                SkillEffect.SPEED_PERCENT to 0.10f
            )
        ),
        EquipmentItem(
            id = "arm_juggernaut_plate",
            name = "Juggernaut Plate",
            slot = EquipmentSlot.ARMOR,
            rarity = Rarity.EPIC,
            description = "+22% max HP, +10% lifesteal",
            bonuses = mapOf(
                SkillEffect.HP_PERCENT to 0.22f,
                SkillEffect.LIFESTEAL_PERCENT to 0.10f
            )
        ),
        EquipmentItem(
            id = "arm_wraith_mantle",
            name = "Wraith Mantle",
            slot = EquipmentSlot.ARMOR,
            rarity = Rarity.RARE,
            description = "+10% max HP, +20% special damage",
            bonuses = mapOf(
                SkillEffect.HP_PERCENT to 0.10f,
                SkillEffect.SPECIAL_DAMAGE_PERCENT to 0.20f
            )
        )
    )

    fun byId(id: String): EquipmentItem? = ALL.firstOrNull { it.id == id }
    fun weapons(): List<EquipmentItem> = ALL.filter { it.slot == EquipmentSlot.WEAPON }
    fun armors(): List<EquipmentItem> = ALL.filter { it.slot == EquipmentSlot.ARMOR }

    /**
     * Rolls a random item using rarity-weighted odds. Returns null if the
     * roll misses entirely (controlled by dropChance in the caller) — this
     * function itself always returns an item, the "did it drop at all"
     * check happens before calling this.
     */
    fun rollRandomItem(): EquipmentItem {
        val totalWeight = ALL.sumOf { it.rarity.dropWeight }
        var roll = Random.nextInt(totalWeight)
        for (item in ALL) {
            if (roll < item.rarity.dropWeight) return item
            roll -= item.rarity.dropWeight
        }
        return ALL.last()
    }
}
