package com.shadowbrawler.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

interface GameListener {
    fun onGameOver(victory: Boolean, soulsEarned: Int, waveReached: Int, droppedItemIds: List<String>)
}

class GameView(
    context: Context,
    private val characterDef: CharacterDef,
    private val unlockedSkills: List<SkillNode>,
    private val equippedItems: List<EquipmentItem>,
    private val listener: GameListener
) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    @Volatile private var running = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val groundY = 900f
    private var screenW = 1600f
    private var screenH = 1000f

    private lateinit var player: Fighter
    private val enemies = mutableListOf<Fighter>()

    private var waveNumber = 1
    private var enemiesRemainingInWave = 3
    private var soulsEarned = 0
    private val droppedItemIds = mutableListOf<String>()

    @Volatile private var movingLeft = false
    @Volatile private var movingRight = false
    @Volatile private var requestAttack = false
    @Volatile private var requestSpecial = false

    private var btnLeft = RectF()
    private var btnRight = RectF()
    private var btnAttack = RectF()
    private var btnSpecial = RectF()

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        screenW = width.toFloat()
        screenH = height.toFloat()
        setupControls()
        player = Fighter.buildPlayer(characterDef, unlockedSkills, equippedItems, screenW * 0.2f, groundY)
        spawnWave()
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        screenW = w.toFloat()
        screenH = h.toFloat()
        setupControls()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        thread?.join()
    }

    private fun setupControls() {
        val btnSize = screenH * 0.16f
        val margin = 24f
        btnLeft = RectF(margin, screenH - btnSize - margin, margin + btnSize, screenH - margin)
        btnRight = RectF(margin * 2 + btnSize, screenH - btnSize - margin, margin * 2 + btnSize * 2, screenH - margin)
        btnSpecial = RectF(screenW - margin - btnSize, screenH - btnSize - margin, screenW - margin, screenH - margin)
        btnAttack = RectF(screenW - margin * 2 - btnSize * 2, screenH - btnSize - margin, screenW - margin * 2 - btnSize, screenH - margin)
    }

    private fun spawnWave() {
        enemies.clear()
        enemiesRemainingInWave = min(3 + waveNumber / 2, 6)
        spawnNextEnemyIfNeeded()
    }

    private fun spawnNextEnemyIfNeeded() {
        if (enemies.size < 2 && enemiesRemainingInWave > 0) {
            val spawnX = screenW * 0.85f
            enemies.add(Fighter.buildEnemy(waveNumber, spawnX, groundY))
            enemiesRemainingInWave--
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        var left = false
        var right = false
        var attack = false
        var special = false

        val liftedIndex = when (event.actionMasked) {
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> event.actionIndex
            else -> -1
        }

        if (event.actionMasked != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until event.pointerCount) {
                if (i == liftedIndex) continue
                val px = event.getX(i)
                val py = event.getY(i)
                if (btnLeft.contains(px, py)) left = true
                if (btnRight.contains(px, py)) right = true
                if (btnAttack.contains(px, py)) attack = true
                if (btnSpecial.contains(px, py)) special = true
            }
        }

        movingLeft = left
        movingRight = right
        requestAttack = attack
        requestSpecial = special
        return true
    }

    override fun run() {
        var lastTime = System.currentTimeMillis()
        while (running) {
            val now = System.currentTimeMillis()
            val dt = (now - lastTime).coerceAtMost(50)
            lastTime = now

            update(now, dt)
            draw()

            try { Thread.sleep(16) } catch (e: InterruptedException) { }
        }
    }

    private fun update(now: Long, dt: Long) {
        if (!player.isAlive) {
            endGame(false)
            return
        }

        if (movingLeft) player.x -= player.speed
        if (movingRight) player.x += player.speed
        player.x = player.x.coerceIn(40f, screenW - 40f)
        player.facingRight = enemies.firstOrNull()?.let { it.x >= player.x } ?: player.facingRight

        if (requestAttack && player.canBasicAttack(now)) {
            player.startBasicAttack(now)
            resolvePlayerHit(player.damage)
        }
        if (requestSpecial && player.canSpecial(now) && player.specialDamage > 0) {
            player.startSpecial(now)
            resolvePlayerHit(player.specialDamage)
        }
        if (player.isAttacking && now > player.attackAnimEndTime) player.isAttacking = false

        val iterator = enemies.iterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            if (!e.isAlive) {
                soulsEarned += 5
                iterator.remove()
                continue
            }
            val dist = e.x - player.x
            if (abs(dist) > 90f) {
                e.x -= if (dist > 0) e.speed else -e.speed
            } else if (e.canBasicAttack(now)) {
                e.startBasicAttack(now)
                player.takeDamage(e.damage)
            }
            if (e.isAttacking && now > e.attackAnimEndTime) e.isAttacking = false
        }

        spawnNextEnemyIfNeeded()

        if (enemies.isEmpty() && enemiesRemainingInWave == 0) {
            waveNumber++
            soulsEarned += 15
            rollWaveDrop()
            if (waveNumber > 10) {
                endGame(true)
            } else {
                spawnWave()
            }
        }
    }

    /** 35% chance per cleared wave to drop a random rarity-weighted item. */
    private fun rollWaveDrop() {
        if (kotlin.random.Random.nextFloat() < 0.35f) {
            droppedItemIds.add(EquipmentCatalog.rollRandomItem().id)
        }
    }

    private fun resolvePlayerHit(damage: Int) {
        val target = enemies.minByOrNull { abs(it.x - player.x) } ?: return
        if (abs(target.x - player.x) <= 120f) {
            target.takeDamage(damage)
            if (player.lifestealPercent > 0f) {
                player.heal((damage * player.lifestealPercent).toInt())
            }
        }
    }

    private fun endGame(victory: Boolean) {
        running = false
        post { listener.onGameOver(victory, soulsEarned, waveNumber, droppedItemIds.toList()) }
    }

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            drawBackground(canvas)
            drawFighter(canvas, player)
            for (e in enemies) drawFighter(canvas, e)
            drawHud(canvas)
            drawControls(canvas)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun drawBackground(canvas: Canvas) {
        paint.color = Color.parseColor("#0D0D14")
        canvas.drawRect(0f, 0f, screenW, screenH, paint)
        paint.color = Color.parseColor("#1A1A24")
        canvas.drawRect(0f, groundY + 30f, screenW, screenH, paint)
        paint.color = Color.parseColor("#2A2A38")
        canvas.drawRect(0f, groundY + 30f, screenW, groundY + 35f, paint)
    }

    private fun drawFighter(canvas: Canvas, f: Fighter) {
        if (!f.isAlive) return
        paint.color = f.color
        val w = 60f
        val h = 140f
        val top = f.groundY - h
        val flash = if (f.isAttacking) 20f else 0f
        canvas.drawRoundRect(
            RectF(f.x - w / 2 - flash / 2, top, f.x + w / 2 + flash / 2, f.groundY),
            16f, 16f, paint
        )
        val barW = 80f
        paint.color = Color.parseColor("#33000000")
        canvas.drawRect(f.x - barW / 2, top - 24f, f.x + barW / 2, top - 12f, paint)
        paint.color = if (f.isEnemy) Color.parseColor("#E63946") else Color.parseColor("#4CAF50")
        val pct = f.hp.toFloat() / f.maxHp.toFloat()
        canvas.drawRect(f.x - barW / 2, top - 24f, f.x - barW / 2 + barW * pct, top - 12f, paint)
    }

    private fun drawHud(canvas: Canvas) {
        paint.color = Color.WHITE
        paint.textSize = 42f
        canvas.drawText("Wave $waveNumber", 30f, 60f, paint)
        canvas.drawText("Souls: $soulsEarned", 30f, 110f, paint)
        canvas.drawText(player.name + "  HP: ${max(0, player.hp)}/${player.maxHp}", 30f, 160f, paint)
    }

    private fun drawControls(canvas: Canvas) {
        paint.color = Color.parseColor("#552A2A38")
        canvas.drawRoundRect(btnLeft, 20f, 20f, paint)
        canvas.drawRoundRect(btnRight, 20f, 20f, paint)
        paint.color = Color.parseColor("#55E8B84B")
        canvas.drawRoundRect(btnAttack, 20f, 20f, paint)
        paint.color = Color.parseColor("#559B30FF")
        canvas.drawRoundRect(btnSpecial, 20f, 20f, paint)

        paint.color = Color.WHITE
        paint.textSize = 36f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("<", btnLeft.centerX(), btnLeft.centerY() + 12f, paint)
        canvas.drawText(">", btnRight.centerX(), btnRight.centerY() + 12f, paint)
        canvas.drawText("ATK", btnAttack.centerX(), btnAttack.centerY() + 12f, paint)
        canvas.drawText("SPC", btnSpecial.centerX(), btnSpecial.centerY() + 12f, paint)
        paint.textAlign = Paint.Align.LEFT
    }
}
