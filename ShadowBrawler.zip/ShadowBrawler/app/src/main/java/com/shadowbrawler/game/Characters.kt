package com.shadowbrawler.game

import android.graphics.Color

/**
 * Defines a playable character archetype. Stats are base values;
 * SkillTree nodes apply permanent multipliers/bonuses on top of these.
 */
data class CharacterDef(
    val id: String,
    val displayName: String,
    val description: String,
    val baseHp: Int,
    val baseDamage: Int,
    val baseSpeed: Float,      // movement speed, px/frame at 60fps baseline
    val attackSpeedMs: Long,   // cooldown between basic attacks
    val color: Int,            // primary silhouette color (stickman tint)
    val specialName: String,
    val specialDamage: Int,
    val specialCooldownMs: Long
)

object Characters {
    val ALL = listOf(
        CharacterDef(
            id = "blade_knight",
            displayName = "Blade Knight",
            description = "Balanced melee fighter. Fast combos, moderate damage.",
            baseHp = 100,
            baseDamage = 8,
            baseSpeed = 6f,
            attackSpeedMs = 280,
            color = Color.parseColor("#E8B84B"),
            specialName = "Dragon Slash",
            specialDamage = 35,
            specialCooldownMs = 4000
        ),
        CharacterDef(
            id = "shadow_assassin",
            displayName = "Shadow Assassin",
            description = "High speed, low HP, brutal critical strikes.",
            baseHp = 75,
            baseDamage = 6,
            baseSpeed = 9f,
            attackSpeedMs = 180,
            color = Color.parseColor("#9B30FF"),
            specialName = "Void Dash",
            specialDamage = 28,
            specialCooldownMs = 3200
        ),
        CharacterDef(
            id = "iron_juggernaut",
            displayName = "Iron Juggernaut",
            description = "Slow but devastating. Massive HP and hit-stun.",
            baseHp = 150,
            baseDamage = 14,
            baseSpeed = 4f,
            attackSpeedMs = 420,
            color = Color.parseColor("#E63946"),
            specialName = "Ground Slam",
            specialDamage = 50,
            specialCooldownMs = 5500
        )
    )

    fun byId(id: String): CharacterDef = ALL.first { it.id == id }
}
