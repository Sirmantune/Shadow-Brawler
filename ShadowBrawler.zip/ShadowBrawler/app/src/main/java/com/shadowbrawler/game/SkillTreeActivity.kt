package com.shadowbrawler.game

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SkillTreeActivity : AppCompatActivity() {

    private lateinit var characterId: String
    private lateinit var store: ProgressStore
    private lateinit var skillContainer: LinearLayout
    private lateinit var soulLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skill_tree)

        characterId = intent.getStringExtra("characterId") ?: Characters.ALL.first().id
        store = ProgressStore(this)
        skillContainer = findViewById(R.id.skillContainer)
        soulLabel = findViewById(R.id.soulPointsLabel)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }

        renderTree()
    }

    private fun renderTree() {
        skillContainer.removeAllViews()
        soulLabel.text = "Soul Points: ${store.getSoulPoints()}  |  ${Characters.byId(characterId).displayName}"

        val tree = SkillTrees.treeFor(characterId)
        val inflater = LayoutInflater.from(this)

        for (node in tree) {
            val row = inflater.inflate(R.layout.item_skill_row, skillContainer, false)
            row.findViewById<TextView>(R.id.skillName).text = "T${node.tier} . ${node.name}"
            row.findViewById<TextView>(R.id.skillDesc).text = node.description
            val btn = row.findViewById<Button>(R.id.btnUnlock)

            val unlocked = store.isUnlocked(characterId, node.id)
            val prereqMet = node.requires == null || store.isUnlocked(characterId, node.requires)

            when {
                unlocked -> {
                    btn.text = "UNLOCKED"
                    btn.isEnabled = false
                }
                !prereqMet -> {
                    btn.text = "LOCKED"
                    btn.isEnabled = false
                }
                else -> {
                    btn.text = "${node.cost} pts"
                    btn.isEnabled = true
                    btn.setOnClickListener {
                        if (store.spendSoulPoints(node.cost)) {
                            store.unlock(characterId, node.id)
                            renderTree()
                        }
                    }
                }
            }
            skillContainer.addView(row)
        }
    }
}
